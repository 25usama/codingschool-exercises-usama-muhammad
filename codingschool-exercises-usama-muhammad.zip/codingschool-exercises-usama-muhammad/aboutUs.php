<?php
include 'includes/header.php';
?>

<section id="about" class="about" style="height:90vh;">
    <div class="container">
        <div class="about-content" style="text-align: justify;">
            <h2 style="margin-bottom: 1.5rem; text-align:center;">About Me</h2>

            <p>
                I am a passionate and results-driven web developer with hands-on experience delivering modern and responsive solutions across multiple industries. My work spans university finance systems, consultancy platforms, online education portals, e-commerce solutions, and custom business applications.
            </p>

            <p>
                As an experienced <b style="color: #12f7ff;">Contract-Based Web Developer</b>, I specialize in creating tailored solutions that align perfectly with each client’s requirements. My commitment to staying updated with emerging technologies drives me to build high-quality, scalable, and secure systems.
            </p>

            <p>
                I am currently working as a <b style="color: #12f7ff;">Full Stack Web Developer</b> at Code Center Software House, Peshawar, contributing to innovative, data-driven, and user-centric projects. My expertise includes PHP, MySQL, JavaScript, React, jQuery, SCSS, and AI-powered web solutions.
            </p>

            <p>
                In addition to development, I have a strong understanding of digital marketing and brand-building strategies, enabling businesses to improve their online presence and reach.
            </p>

            <p style="color:#12f7ff;">
                At <b>Code Center Software House</b>, I collaborate with a skilled team delivering services in graphic design, Flutter app development, web and desktop applications, content writing, UI/UX design, and AI-driven digital services. Together, we focus on innovation, quality, and long-term client satisfaction.
            </p>

            <p>
                Whether you are launching a startup, scaling your digital presence, or looking for customized software, I am ready to help you bring your ideas to life. Feel free to contact me to discuss your project — let’s build something exceptional together.
            </p>
        </div>
    </div>
</section>

<footer class="footer">
    <p style="text-align: center;">Copyright &copy; 2025. Developed by Developer_Usama_JDN || All Rights Reserved.</p>
</footer>