<?php
include 'includes/header.php';
?>

<body>

    <!-- header section -------------------------------------------->
    <header>
        <div class="logo"><span>U</span>SAMA_JDN.</div>

        <ul class="navlist">
            <li><a href="#home" class="" style="--i:1;">Home</a></li>
            <li><a href="#about" class="" style="--i:2;">About</a></li>
            <li><a href="#services" class="" style="--i:3;">Services</a></li>
            <li><a href="#skills" class="" style="--i:4;">Skills</a></li>
            <li><a href="#portfolio" class="" style="--i:5;">PortFolio</a></li>
            <li><a href="#contact" class="active" style="--i:7;">Contact</a></li>
        </ul>

        <div id="menu-icon" class="bx bx-menu"></div>
    </header>



    <!-- home section -------------------------------------------->
    <section id="home" class="home">
        <div class="home-content scroll-scale">
            <h1>Hi! I'm Muhammad Usama</h1>

            <div class="change-text">
                <h3>And I'm</h3>
                <h3>
                    <span class="word">Web&nbsp;Developer</span>
                    <span class="word">Full&nbsp;Stack&nbsp;Developer</span>
                    <span class="word">Web&nbsp;Designer</span>
                    <span class="word">Digital&nbsp;Services&nbsp;Provider</span>
                    <span class="word">Freelancer</span>
                </h3>
            </div>

            <p style="text-align: justify;">
                I’m a passionate and detail-oriented Web Developer specializing in modern, responsive, and
                dynamic web applications using PHP, JavaScript, MySQL, and ReactJS. I develop complete
                digital solutions—from elegant UI designs to fully functional systems—focused on performance,
                security, and user experience. As a freelancer and digital services provider, I’ve collaborated
                with both local and international clients, delivering professional websites, management systems,
                and advanced custom features that align with real business goals.
            </p>

            <div class="info-box">
                <div class="email-info">
                    <h5>Email:</h5>
                    <span>usamashafi0011@gmail.com</span>
                </div>

                <div class="contact-info">
                    <h5>Contact:</h5>
                    <span>+92 311 9282703<br>+92 343 8281081</span>
                </div>
            </div>

            <div class="btn-box">
                <a href="documents/CV(latest).pdf" class="btn" target="_blank">Download CV</a>
                <a href="#contact" class="btn">Hire me Now!</a>
            </div>

            <div class="social-icons">
                <!-- GitHub link -->
                <a href="https://github.com/25usama" target="_blank">
                    <i class="bx bxl-github"></i>
                </a>
                <a href="https://www.linkedin.com/in/usama-shafi-46a736242" target="_blank"><i class="bx bxl-linkedin"></i></a>
                <a href="https://www.facebook.com/profile.php?id=100083451115937" target="_blank"><i class="bx bxl-facebook"></i></a>
                <a href="https://www.instagram.com/developer_usama_jdn/" target="_blank"><i class="bx bxl-instagram"></i></a>
                <a href="https://twitter.com/JdnUsama" target="_blank"><i class="bx bxl-twitter"></i></a>
            </div>


        </div>

        <div class="home-image scroll-scale">
            <div class="img-box">
                <img src="imgs/MyPicture-rm-bg.png" alt="Error to load the Pic.">
            </div>

            <!-- browser link for blobs shapes -->
            <!-- https://lokesh-coder.github.io/blobs.app/?e=6&gw=6&se=6688&c=d1d8e0&o=0 -->

            <div class="liquid-shape">
                <svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" id="blobSvg">
                    <path fill="#12f7ff">
                        <animate attributeName="d" dur="20000ms" repeatCount="indefinite" values="
                        M445.5,305Q441,360,398.5,397Q356,434,303,446.5Q250,459,194,452Q138,445,109,396.5Q80,348,59.5,299Q39,250,42,191Q45,132,108.5,123Q172,114,211,84Q250,54,307.5,52.5Q365,51,414,89Q463,127,456.5,188.5Q450,250,445.5,305Z;
                    
                        M444.5,310.5Q459,371,401.5,391.5Q344,412,297,420Q250,428,189.5,444Q129,460,101,406Q73,352,48.5,301Q24,250,36.5,192Q49,134,94,96Q139,58,194.5,49Q250,40,312,37.5Q374,35,408.5,87Q443,139,436.5,194.5Q430,250,444.5,310.5Z;

                        M456.5,304.5Q438,359,392.5,388Q347,417,298.5,433.5Q250,450,205,428.5Q160,407,97,390.5Q34,374,54.5,312Q75,250,93.5,210Q112,170,133,127Q154,84,202,74.5Q250,65,290.5,87Q331,109,364,137Q397,165,436,207.5Q475,250,456.5,304.5Z;

                        M423,289.5Q388,329,373.5,384Q359,439,304.5,445.5Q250,452,190.5,454.5Q131,457,100.5,405.5Q70,354,82.5,302Q95,250,80,196.5Q65,143,114.5,122Q164,101,207,78Q250,55,291.5,80.5Q333,106,383,125Q433,144,445.5,197Q458,250,423,289.5Z;

                        M422.5,289.5Q387,329,363,366.5Q339,404,294.5,409Q250,414,190,435.5Q130,457,92.5,409.5Q55,362,41.5,306Q28,250,39,192Q50,134,102.5,109.5Q155,85,202.5,56Q250,27,298.5,54.5Q347,82,373,123Q399,164,428.5,207Q458,250,422.5,289.5Z;

                        M449.5,306.5Q447,363,393.5,384.5Q340,406,295,446Q250,486,200,455Q150,424,121,382.5Q92,341,60.5,295.5Q29,250,65.5,207Q102,164,117,105Q132,46,191,54Q250,62,309,54Q368,46,412.5,88.5Q457,131,454.5,190.5Q452,250,449.5,306.5Z;

                        M425.5,306Q444,362,396,391Q348,420,299,451Q250,482,209,437Q168,392,107.5,379.5Q47,367,36,308.5Q25,250,49.5,199Q74,148,105.5,101Q137,54,193.5,68Q250,82,306.5,68Q363,54,378.5,110.5Q394,167,400.5,208.5Q407,250,425.5,306Z;

                        M445.5,305Q441,360,398.5,397Q356,434,303,446.5Q250,459,194,452Q138,445,109,396.5Q80,348,59.5,299Q39,250,42,191Q45,132,108.5,123Q172,114,211,84Q250,54,307.5,52.5Q365,51,414,89Q463,127,456.5,188.5Q450,250,445.5,305Z;
                        "></animate>
                    </path>
                </svg>
            </div>

            <!-- shape 2 -->
            <div class="liquid-shape">
                <svg viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="100%" id="blobSvg">
                    <path fill="#12f7ff">
                        <animate attributeName="d" dur="20000ms" repeatCount="indefinite" values="
                        M445.5,305Q441,360,398.5,397Q356,434,303,446.5Q250,459,194,452Q138,445,109,396.5Q80,348,59.5,299Q39,250,42,191Q45,132,108.5,123Q172,114,211,84Q250,54,307.5,52.5Q365,51,414,89Q463,127,456.5,188.5Q450,250,445.5,305Z;
                    
                        M444.5,310.5Q459,371,401.5,391.5Q344,412,297,420Q250,428,189.5,444Q129,460,101,406Q73,352,48.5,301Q24,250,36.5,192Q49,134,94,96Q139,58,194.5,49Q250,40,312,37.5Q374,35,408.5,87Q443,139,436.5,194.5Q430,250,444.5,310.5Z;

                        M456.5,304.5Q438,359,392.5,388Q347,417,298.5,433.5Q250,450,205,428.5Q160,407,97,390.5Q34,374,54.5,312Q75,250,93.5,210Q112,170,133,127Q154,84,202,74.5Q250,65,290.5,87Q331,109,364,137Q397,165,436,207.5Q475,250,456.5,304.5Z;

                        M423,289.5Q388,329,373.5,384Q359,439,304.5,445.5Q250,452,190.5,454.5Q131,457,100.5,405.5Q70,354,82.5,302Q95,250,80,196.5Q65,143,114.5,122Q164,101,207,78Q250,55,291.5,80.5Q333,106,383,125Q433,144,445.5,197Q458,250,423,289.5Z;

                        M422.5,289.5Q387,329,363,366.5Q339,404,294.5,409Q250,414,190,435.5Q130,457,92.5,409.5Q55,362,41.5,306Q28,250,39,192Q50,134,102.5,109.5Q155,85,202.5,56Q250,27,298.5,54.5Q347,82,373,123Q399,164,428.5,207Q458,250,422.5,289.5Z;

                        M449.5,306.5Q447,363,393.5,384.5Q340,406,295,446Q250,486,200,455Q150,424,121,382.5Q92,341,60.5,295.5Q29,250,65.5,207Q102,164,117,105Q132,46,191,54Q250,62,309,54Q368,46,412.5,88.5Q457,131,454.5,190.5Q452,250,449.5,306.5Z;

                        M425.5,306Q444,362,396,391Q348,420,299,451Q250,482,209,437Q168,392,107.5,379.5Q47,367,36,308.5Q25,250,49.5,199Q74,148,105.5,101Q137,54,193.5,68Q250,82,306.5,68Q363,54,378.5,110.5Q394,167,400.5,208.5Q407,250,425.5,306Z;

                        M445.5,305Q441,360,398.5,397Q356,434,303,446.5Q250,459,194,452Q138,445,109,396.5Q80,348,59.5,299Q39,250,42,191Q45,132,108.5,123Q172,114,211,84Q250,54,307.5,52.5Q365,51,414,89Q463,127,456.5,188.5Q450,250,445.5,305Z;
                        "></animate>
                    </path>
                </svg>
            </div>

        </div>


    </section>


    <!-- about section --------------------------------------------->
    <section id="about" class="about">
        <div class="img-about scroll-scale">
            <img src="imgs/MyPicture-rm-bg.png" alt="Error to load Pic">

            <div class="info-about1">
                <span> 1.5+ </span>
                <p>Years of Experience</p>
            </div>

            <div class="info-about2">
                <span> 15+ </span>
                <p>Projects Completed</p>
            </div>

            <div class="info-about3">
                <span> 10+ </span>
                <p>Happy Clients</p>
            </div>
        </div>

        <div class="about-content scroll-scale">
            <span>Let me Introduce Myself</span>
            <h2>About Me</h2>
            <h3>Who I Am & What I Do</h3>

            <p style="text-align: justify;">
                I am a passionate Web Developer and Digital Services Provider with hands-on experience in building
                modern, responsive, and high-performing web applications. I specialize in PHP, JavaScript, MySQL,
                and ReactJS, and I’ve delivered successful solutions across various industries, including university
                finance, consultancy, online education, e-commerce, and service-based businesses.
                <br><br>
                My focus is to create clean, functional, and visually appealing digital products that solve real
                problems. I bring strong technical expertise, sharp problem-solving skills, and a commitment to
                delivering high-quality results for every project I work on.
            </p>

            <div class="btn-box">
                <a href="aboutUs.php" class="btn">Read More</a>
            </div>
        </div>
    </section>


    <!-- services section  ------------------------------------------------->
    <section id="services" class="services">

        <div class="main-text scroll-scale">
            <span>What I Can Do For You</span>
            <h2>My Services</h2>
        </div>

        <div class="section-services scroll-bottom">

            <!-- Web Development -->
            <div class="service-box">
                <i class="bx bx-desktop service-icon"></i>
                <h3>Web App Development</h3>
                <p style="text-align: justify;">
                    I develop secure, fast, and fully functional web applications using PHP, MySQL,
                    JavaScript, and modern frameworks. Whether it’s a custom system, CRM, LMS, business
                    dashboard, or fully dynamic platform, I build solutions tailored to your exact needs.
                </p>
                <div class="btn-box service-btn">
                    <a href="#" class="btn">Read More</a>
                </div>
            </div>

            <!-- Website Design -->
            <div class="service-box">
                <i class="bx bx-code-alt service-icon"></i>
                <h3>Website Development & Design</h3>
                <p style="text-align: justify;">
                    I create modern, responsive, and visually appealing websites with clean UI/UX,
                    optimized performance, and seamless user experience. Perfect for businesses, startups,
                    portfolios, e-commerce, and personal brands.
                </p>
                <div class="btn-box service-btn">
                    <a href="#" class="btn">Read More</a>
                </div>
            </div>

            <!-- Digital Services -->
            <div class="service-box">
                <i class="bx bxs-layer service-icon"></i>
                <h3>Digital & IT Services</h3>
                <p style="text-align: justify;">
                    From website management, bug fixing, integrations, automation, and API services
                    to digital consultancy and technical support — I help businesses streamline their
                    online presence with reliable and professional digital solutions.
                </p>
                <div class="btn-box service-btn">
                    <a href="#" class="btn">Read More</a>
                </div>
            </div>

        </div>

    </section>



    <!-- skill section  -------------------------------------->
    <section id="skills" class="skills">
        <div class="main-text scroll-scale">
            <span>Technical and Professional</span>
            <h2>My Skills</h2>
        </div>

        <div class="skill-main">

            <!-- Technical Skills -->
            <div class="skill-left scroll-scale">
                <h3>Technical Skills</h3>

                <div class="skill-bar">
                    <div class="info">
                        <p>PHP</p>
                        <p>90%</p>
                    </div>
                    <div class="bar">
                        <span class="php"></span>
                    </div>
                </div>

                <div class="skill-bar">
                    <div class="info">
                        <p>JavaScript</p>
                        <p>80%</p>
                    </div>
                    <div class="bar">
                        <span class="js"></span>
                    </div>
                </div>

                <div class="skill-bar">
                    <div class="info">
                        <p>MySQL</p>
                        <p>85%</p>
                    </div>
                    <div class="bar">
                        <span class="mysql"></span>
                    </div>
                </div>

                <div class="skill-bar">
                    <div class="info">
                        <p>React JS</p>
                        <p>70%</p>
                    </div>
                    <div class="bar">
                        <span class="reactjs"></span>
                    </div>
                </div>

                <div class="skill-bar">
                    <div class="info">
                        <p>jQuery</p>
                        <p>75%</p>
                    </div>
                    <div class="bar">
                        <span class="jquery"></span>
                    </div>
                </div>

            </div>

            <!-- Professional Skills -->
            <div class="skill-right scroll-scale">
                <h3>Professional Skills</h3>
                <div class="professional">

                    <div class="box">
                        <div class="circle" data-dots="100" data-percent="100"></div>
                        <div class="text">
                            <big>100%</big>
                            <small>Teamwork</small>
                        </div>
                    </div>

                    <div class="box">
                        <div class="circle" data-dots="90" data-percent="90"></div>
                        <div class="text">
                            <big>90%</big>
                            <small>Project Management</small>
                        </div>
                    </div>

                    <div class="box">
                        <div class="circle" data-dots="85" data-percent="85"></div>
                        <div class="text">
                            <big>85%</big>
                            <small>Creativity</small>
                        </div>
                    </div>

                    <div class="box">
                        <div class="circle" data-dots="95" data-percent="95"></div>
                        <div class="text">
                            <big>95%</big>
                            <small>Process Implementation</small>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </section>



    <!-- portfolio section ----------------------------------------->
    <section id="portfolio" class="portfolio">
        <div class="main-text scroll-scale">
            <span>What I Have Built</span>
            <h2>Latest Projects</h2>
        </div>

        <div class="container">
            <div class="fillter-buttons scroll-scale">
                <button class="button" data-filter="all">All</button>
                <button class="button" data-filter="website">Websites</button>
                <button class="button" data-filter="webapp">Web Apps</button>
                <button class="button" data-filter="graphics">Graphic Designing</button>
                <button class="button" data-filter="crm">CRM Systems</button>
            </div>

            <div class="portfolio-gallery scroll-bottom">

                <!-- Idealogy Creations Website -->
                <div class="port-box" data-item="website">
                    <div class="port-image">
                        <img src="imgs/projects/project (2).png" class="project-img" alt="Idealogy Creations Website">
                    </div>
                    <div class="port-content">
                        <h3>Idealogy Website</h3>
                        <p>
                            A modern, responsive and animation-rich website built for a digital software company.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

                <!-- Management System -->
                <div class="port-box" data-item="webapp">
                    <div class="port-image">
                        <img src="imgs/projects/home.png" class="project-img" alt="Management System">
                    </div>
                    <div class="port-content">
                        <h3>Management System</h3>
                        <p>
                            A complete management system featuring an admin dashboard and secure authentication.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

                <!-- Admin Panels -->
                <div class="port-box" data-item="webapp">
                    <div class="port-image">
                        <img src="imgs/projects/project (3).png" class="project-img" alt="Admin Panels">
                    </div>
                    <div class="port-content">
                        <h3>Advanced Admin Panels</h3>
                        <p>
                            designed for multiple clients, including role-based access,
                            CRUD functionality.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

                <!-- CRM System -->
                <div class="port-box" data-item="crm">
                    <div class="port-image">
                        <img src="imgs/projects/project (1).png" class="project-img" alt="CRM Salon Management System">
                    </div>
                    <div class="port-content">
                        <h3>CRM – Salon Management</h3>
                        <p>
                            A fully functional CRM built for salon operations, covering appointments, staff scheduling,
                            customers, etc.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

                <!-- Logos -->
                <div class="port-box" data-item="graphics">
                    <div class="port-image">
                        <img src="imgs/projects/logo high-quality.png" class="project-img" alt="Logo Designing Work">
                    </div>
                    <div class="port-content">
                        <h3>Logos Portfolio</h3>
                        <p>
                            A collection of creative logos designed for different brands with modern, minimal, and
                            visually appealing concepts enhancing brand identity.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

                <!-- Social Media Designs -->
                <div class="port-box" data-item="graphics">
                    <div class="port-image">
                        <img src="imgs/projects/BlueBarsForex Post 2.png" class="project-img" alt="Social Media Designs">
                    </div>
                    <div class="port-content">
                        <h3>Social Media Designing</h3>
                        <p>
                            Professionally designed posts, covers, and promotional graphics created for businesses to
                            boost their social media presence and brand visibility.
                        </p>
                        <a href="#"><i class="bx bx-link-external"></i></a>
                    </div>
                </div>

            </div>
        </div>

        <!-- pagination buttons -->
        <div class="pagination-controls">
            <button class="prev-button btn">&#10094;</button>
            <button class="next-button btn">&#10095;</button>
        </div>

        <!-- modal for images -->
        <!-- MODAL POPUP -->
        <div id="imgModal" class="modal">
            <span class="modal-close">&times;</span>
            <img class="modal-content" id="modalImage">
            <div class="caption" id="caption"></div>
        </div>

    </section>



    <!-- contact section  ---------------------------------->
    <section id="contact" class="contact">
        <div class="main-text scroll-scale">
            <span>Ask me a Question</span>
            <h2>Contact Me</h2>
        </div>

        <!-- for Formsubmit.co (used for to recieve emails, we can also use genrated link except of my email) -->
        <form action="https://formsubmit.co/usamashafi0011@gmail.com" method="POST" class="scroll-bottom">
            <!-- for Formspree (used for to recieve emails) -->
            <!-- <form action=" https://formspree.io/f/moqodbla" method="POST" class="scroll-bottom"> -->

            <input type="text" name="name" placeholder="Your Name">
            <input type="email" name="email" placeholder="Your Email">
            <input type="text" name="address" placeholder="Your Address">
            <input type="number" name="phone" placeholder="Phone Number">
            <textarea name="textarea" name="textarea" id="" cols="30" rows="10" placeholder="Your Message">
            </textarea>

            <div class="btn-box formBtn">
                <button type="submit" class="btn">Send Message</button>
            </div>
        </form>

    </section>


    <!-- footer section ----------------------------->
    <?php
    include 'includes/footer.php';
    ?>
    <!-- link for js -->
    <script src="scripts/script.js"></script>

</body>

</html>