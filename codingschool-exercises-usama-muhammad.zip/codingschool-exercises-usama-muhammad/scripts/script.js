let words = document.querySelectorAll(".word");

words.forEach((word) => {
    let letters = word.textContent.split("");
    word.textContent = "";

    letters.forEach((letter) => {
        let span = document.createElement("span");
        span.textContent = letter;
        span.className = "letter";
        word.append(span);
    });
});

let currentWordIndex = 0;
let maxWordIndex = words.length - 1;

words[currentWordIndex].style.opacity = "1";

let changeText = () => {
    let currentWord = words[currentWordIndex];
    let nextWord = currentWordIndex === maxWordIndex ? words[0] : words[currentWordIndex + 1];

    Array.from(currentWord.children).forEach((letter, i) => {
        setTimeout(() => {
            letter.className = "letter out";
        }, i * 80);
    });

    nextWord.style.opacity = "1";

    Array.from(nextWord.children).forEach((letter, i) => {
        letter.className = "letter behind";

        setTimeout(() => {
            letter.className = "letter in";
        }, 340 + i * 80);
    });

    currentWordIndex = currentWordIndex === maxWordIndex ? 0 : currentWordIndex = 1;

};

changeText();

setInterval(changeText, 3000)


// circle professional skills
const circles = document.querySelectorAll('.circle');
circles.forEach(elem => {
    var dots = elem.getAttribute("data-dots");
    var marked = elem.getAttribute("data-percent");
    var percent = Math.floor(dots * marked / 100);
    var points = "";
    var rotate = 360 / dots;

    for (let i = 0; i < dots; i++) {
        points += `<div class="points" style="--i:${i}; --rot:${rotate}deg"></div>`;
    }
    elem.innerHTML = points;

    const pointsMarked = elem.querySelectorAll('.points');

    for (let i = 0; i < percent; i++) {
        pointsMarked[i].classList.add('marked')
    }
})



// active menu link
let menuLi = document.querySelectorAll('header ul li a');
let section = document.querySelectorAll('section');

function activeMenu() {
    let len = section.length;
    while (--len && window.scrollY + 97 < section[len].offsetTop) { }
    menuLi.forEach(sec => sec.classList.remove("active"));
    menuLi[len].classList.add("active");
}

activeMenu();
window.addEventListener("scroll", activeMenu);


// sticky navbar 
const header = document.querySelector("header");
window.addEventListener("scroll", function () {
    header.classList.toggle("sticky" ,window.scrollY > 50)
})

// toggle bar for small screens
let menuIcon = document.querySelectorAll("#menu-icon");
let navlist = document.querySelectorAll(".navlist");

menuIcon.onClick = () => {
    menuIcon.classList.toggle("bx-x");
    navlist.classList.toggle("open");
}

menuIcon.onscroll = () => {
    menuIcon.classList.remove("bx-x");
    navlist.classList.remove("open");
}

// parallax 
const observer = new IntersectionObserver((entries) => {
    entries.forEach((entry) => {
        if (entry.isIntersecting) {
            entry.target.classList.add("show-items");
        } else {
            entry.target.classList.remove("show-items");
        }
    });
});

const scrollScale = document.querySelectorAll(".scroll-scale");
scrollScale.forEach((el) => observer.observe(el));

const scrollBottom = document.querySelectorAll(".scroll-bottom");
scrollBottom.forEach((el) => observer.observe(el));

const scrollTop = document.querySelectorAll(".scroll-top");
scrollScale.forEach((el) => observer.observe(el));



// pagination functionality for portfolio section
const prevButton = document.querySelector('.prev-button');
const nextButton = document.querySelector('.next-button');
const projectBoxes = document.querySelectorAll('.port-box');
const boxesPerPage = 4;
let currentPage = 0;

function showBoxes(page) {
    const startIndex = page * boxesPerPage;
    const endIndex = startIndex + boxesPerPage;

    projectBoxes.forEach((box, index) => {
        if (index >= startIndex && index < endIndex) {
            box.style.display = 'block';
        } else {
            box.style.display = 'none';
        }
    });
}

function handlePageChange(change) {
    currentPage += change;
    if (currentPage < 0) {
        currentPage = 0;
    } else if (currentPage >= Math.ceil(projectBoxes.length / boxesPerPage)) {
        currentPage = Math.floor(projectBoxes.length / boxesPerPage);
    }
    showBoxes(currentPage);
}

prevButton.addEventListener('click', () => {
    handlePageChange(-1);
});

nextButton.addEventListener('click', () => {
    handlePageChange(1);
});

// Initial display
showBoxes(currentPage);


// script for modal
const modal = document.getElementById('imgModal');
const modalImg = document.getElementById('modalImage');
const caption = document.getElementById('caption');
const closeModal = document.querySelector('.modal-close');

document.querySelectorAll('.port-box').forEach(box => {
  box.addEventListener('click', () => {
    const img = box.querySelector('.project-img');
    modal.style.display = 'block';
    modalImg.src = img.src;
    caption.textContent = img.alt;
  });
});


closeModal.onclick = () => modal.style.display = "none";

window.onclick = (event) => {
  if (event.target == modal) {
    modal.style.display = "none";
  }
};
