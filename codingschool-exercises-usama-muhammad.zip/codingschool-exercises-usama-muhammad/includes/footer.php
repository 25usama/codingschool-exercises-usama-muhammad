    <footer class="footer">
      <p class="scroll-scale">Copyright &copy; 2025. Developed by Developer_Usama_JDN || All Rights Reserved.</p>
      <a href="#home"><i class="bx bx-up-arrow-alt"></i></a>
    </footer>