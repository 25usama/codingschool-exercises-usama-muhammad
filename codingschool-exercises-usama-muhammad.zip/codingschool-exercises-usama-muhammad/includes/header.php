<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Welcome to my PortFolio | Work</title>

  <!-- link for favicon -->
  <link rel="icon" href="imgs/MyPicture-rm-bg.png" type="image/x-icon">
  <link rel="shortcut icon" href="imgs/MyPicture-rm-bg.png" type="image/x-icon">


  <!-- link for box icons -->
  <!-- <link rel="stylesheet" type="text/css" href="styles/boxicons.min.css"> -->
  <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>

  <!-- link for css style -->
  <link rel="stylesheet" type="text/css" href="styles/style.css">

</head>